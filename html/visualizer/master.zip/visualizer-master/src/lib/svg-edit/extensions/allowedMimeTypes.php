<?php

$allowedMimeTypesBySuffix = array(
    'svg' => 'image/svg+xml;charset=UTF-8',
    'png' => 'image/png',
    'jpeg' => 'image/jpeg',
    'bmp' => 'image/bmp',
    'webp' => 'image/webp',
	'pdf' => 'application/pdf'
);

?>