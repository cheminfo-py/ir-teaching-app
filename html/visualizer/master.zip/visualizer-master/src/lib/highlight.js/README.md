# highlight.js

https://github.com/isagalaev/highlight.js

## Build

`node tools/build.js :common`

Copy CSS files from src/styles